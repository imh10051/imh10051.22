import java.util.Scanner;

public class ASS3qs5 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the size of Array:");
        int n=input.nextInt();
        System.out.println("Enter the array:");
        for (int i=0;i<n-1;i++){
            int[] marks = new int[n];
            marks[i]=input.nextInt();
//            for (int j=n-1;j>0;j--){
//                System.out.println(marks[j]);
//            }
        }


    }
}
