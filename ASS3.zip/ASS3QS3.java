

class VarArgs{

    public static void  Length_Argument(int ...arr){
        System.out.println("The length of Argument is:"+arr.length);

    }

    public static int Max_Number(int ...arr){
        int max=arr[0];
        for (int element:arr
             ) {
            if (element>max){
                max=element;
            }

        }
        return max;

    }

    public static int Sum(int ...arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            //sum = 0;
            sum = sum + arr[i];

        }
        //System.out.println("The sum of all the arguments in the array is:" + sum);

        return sum;
    }

    public static int Array_Reverse(int ...arr){
        for (int i = arr.length-1; i >0 ; i--) {
            System.out.println(arr[i]);


        }

        //return false;
        return 0;
    }


}




public class ASS3QS3 {
    public static void main(String[] args) {
        VarArgs.Length_Argument(78,89,25);

        int maxNumber= VarArgs.Max_Number(78,89,56,55,789,56);

        System.out.println("Maximum element in the list is:"+ maxNumber);

        int sum=VarArgs.Sum(78,89,56,55,789,56);
        System.out.println("The sum of the given array is:"+sum);

        int Rev=VarArgs.Array_Reverse(78,89,56,55,789,56);
        System.out.print("The reversed array:"+Rev);



    }
}
