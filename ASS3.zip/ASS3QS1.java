import java.util.Scanner;

/*Consider a scenario where three shapes are given and depending on the
shape you need to find the area or circumference or perimeter. The shapes
are rectangle, circle and square. Write a program for the same and use
method overloading to implement the above-mentioned task.*/
//////////////////////////////////////Method Overloading/////////////////////////////////////////////
class Shapes{
    //Area
    public static  int Area(int length,int breadth){

        return length*breadth;
    }

    public static double Area(int radius){
        return 3.14*radius*radius;
    }

    public static int Area(double side){
        return (int) (side*side);//typecasting to int
    }

    public static int Perimeter(int length,int breadth){
        return 2*(length+breadth);
    }

    public static int Perimeter(int side){
        return 4*side;
    }

}



public class ASS3QS1 {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value of radius:");
        int radius=sc.nextInt();
        Shapes obj=new Shapes();
        System.out.println(Shapes.Area(radius));


    }
}
