import java.util.Scanner;

public class ASS3QS2 {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        System.out.println("Enter the Name of the customer:");
        String Name=input.next();
        System.out.println("Enter the age of the customer:");
        int Age=input.nextInt();
//        if (Name.toString()==Name){
//            System.out.println("OK");
//
//        }
//        else {
//            System.out.println("Rewrite");
//        }
        for (int i=0;i<Name.length();i++){
            for (int j=0;j<10;j++){
                if (Name.charAt(i)=='j' ){

                    System.out.println("You have not entered a proper name");
                }

            }

        }//System.out.println("All ok");
        if (Age>3 && Age<15){
            System.out.println("Validated");
        }
        else {
            System.out.println("Not validated");
        }

    }
}
